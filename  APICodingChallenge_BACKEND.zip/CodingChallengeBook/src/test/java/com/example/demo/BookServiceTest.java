package com.example.demo;


import com.example.demo.Entity.Book;
import com.example.demo.Repository.BookRepository;
import com.example.demo.Service.BookService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class BookServiceTest {

    @Mock
    private BookRepository repo;

    @InjectMocks
    private BookService service;

    private Book book;

    @BeforeEach
    void setup() {
        book = new Book("123", "Java", "James", 2020);
    }

   
    @Test
    void testGetAllBooks() {
        when(repo.findAll()).thenReturn(List.of(book));

        List<Book> result = service.getAllBooks();

        assertEquals(1, result.size());
        assertEquals("Java", result.get(0).getTitle());
    }

    @Test
    void testGetBook_Success() {
        when(repo.findById("123")).thenReturn(Optional.of(book));

        Book result = service.getBook("123");

        assertNotNull(result);
        assertEquals("Java", result.getTitle());
    }

    @Test
    void testGetBook_NotFound() {
        when(repo.findById("999")).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class,
                () -> service.getBook("999"));
    }

   
    @Test
    void testAddBook() {
        when(repo.save(book)).thenReturn(book);

        Book result = service.addBook(book);

        assertEquals("Java", result.getTitle());
        verify(repo, times(1)).save(book);
    }

    @Test
    void testUpdateBook() {
        Book updated = new Book("123", "Spring", "Rod", 2022);

        when(repo.existsById("123")).thenReturn(true);
        when(repo.findById("123")).thenReturn(Optional.of(book));
        when(repo.save(any(Book.class))).thenReturn(updated);

        Book result = service.updateBook("123", updated);

        assertEquals("Spring", result.getTitle());
        assertEquals(2022, result.getPublicationYear());
    }

    @Test
    void testUpdateBook_NotFound() {
        when(repo.existsById("999")).thenReturn(false);

        Book updated = new Book("999", "Spring", "Rod", 2022);

        assertThrows(RuntimeException.class,
                () -> service.updateBook("999", updated));
    }

    @Test
    void testDeleteBook() {
        when(repo.existsById("123")).thenReturn(true);
        doNothing().when(repo).deleteById("123");

        String result = service.deleteBook("123");

        assertEquals("deleted", result);
        verify(repo, times(1)).deleteById("123");
    }

    @Test
    void testDeleteBook_NotFound() {
        when(repo.existsById("999")).thenReturn(false);

        assertThrows(RuntimeException.class,
                () -> service.deleteBook("999"));
    }

}
