package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.Book;
import com.example.demo.Service.BookService;

@RestController
@RequestMapping("BookApi")
public class BookController {
	@Autowired
	BookService service;
	 @PostMapping("/AddBook")
	    public ResponseEntity<Book> create(@RequestBody Book book) {
	        Book savedBook = service.addBook(book);
	        return new ResponseEntity<>(savedBook, HttpStatus.CREATED);
	    }
	 @GetMapping("/getByIsbn/{isbn}")
	    public ResponseEntity<Book> getByIsbn(@PathVariable String isbn) {
	        Book book = service.getBook(isbn);
	        return ResponseEntity.ok(book);
	    }
	  @GetMapping("/ShowAllBook")
	    public List<Book> getAll() {
	        return service.getAllBooks();
	    }
	  @PutMapping("Update/{isbn}")
	    public Book update(@PathVariable String isbn, @RequestBody Book book) {
	        return service.updateBook(isbn, book);
	    }
	  @DeleteMapping("Delete/{isbn}")
	    public String delete(@PathVariable String isbn) {
	       return service.deleteBook(isbn);
	    }

}
