package com.example.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.demo.Entity.Book;
import com.example.demo.Repository.BookRepository;

@Service
public class BookService {
	@Autowired
	BookRepository repo;

	public Book addBook(Book book) {
		if (repo.existsById(book.getIsbn())) {
            throw new RuntimeException("Book already exists with ISBN: " + book.getIsbn());
        }

        return repo.save(book);
    
    }
	 public List<Book> getAllBooks() {
	        return repo.findAll();
	    }
	 
	 public Book getBook(String isbn) {
		 return repo.findById(isbn)
		            .orElseThrow(() ->
		                new RuntimeException("Book not found with ISBN: " + isbn));
	    }
	 
	 public Book updateBook(String isbn, Book updated) {
		 
		 if (!repo.existsById(isbn)) {
		        throw new RuntimeException("Book not found with ISBN to Update: " + isbn);
		    }
		 
	        Book oldbook = getBook(isbn);
	        oldbook.setTitle(updated.getTitle());
	        oldbook.setAuthor(updated.getAuthor());
	        oldbook.setPublicationYear(updated.getPublicationYear());
	        return repo.save(oldbook);
	    }
	 public String deleteBook(String isbn) {

		    if (!repo.existsById(isbn)) {
		        throw new RuntimeException("Book not found with ISBN: " + isbn);
		    }

		    repo.deleteById(isbn);
		    return "deleted";
	    }

}
